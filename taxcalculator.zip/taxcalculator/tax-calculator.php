<?php
/**
 * Plugin Name: Tax Calculator
 * Description: Calculates and displays a price range based on user input.
 * Version: 1.1
 * Author: Propellex
 */

function tax_calculator_enqueue_assets() {
    // Ensure to replace 'your-script' with the actual path to your JavaScript file.
    wp_enqueue_script('tax-calculator-js', plugin_dir_url(__FILE__) . 'calculator.js', array('jquery'), '1.1', true);

    // Enqueue CSS
    wp_enqueue_style('tax-calculator-css', plugin_dir_url(__FILE__) . 'tax-calculator-styles.css', array(), '1.1', 'all');
}

add_action('wp_enqueue_scripts', 'tax_calculator_enqueue_assets');

function tax_calculator_shortcode() {
    ob_start();
    ?>
    <div id="tax-calculator">
    <form id="tax-calculator-form">
        <!--<h2>How Much Will It Cost To Get the Individual Tax Planning Service?</h2> -->
        <!-- Step 1 -->
        <div class="form-step active-step" id="step-1">
        <div class="question-container">
            <div class="question"><span class="question-number">1</span>What is your filing status?</div>
            <select id="filing-status" name="filing-status" class="option">
                <option value="250">Single</option>
                <option value="250">Married Filing Jointly</option>
                <option value="250">Married Filing Separately</option>
                <option value="250">Head of Household</option>
                <option value="250">Qualifying Widow(er) with Dependent Child</option>
            </select>
        </div>
        <div class="button-container">
        <button type="button" class="next-btn">Next</button>
        </div>
        </div>
        <!-- Step 2 -->
        <div class="form-step" id="step-2" style="display:none;">
        <div class="question-container">
            <div class="question"><span class="question-number">2</span>Do you have any dependents?</div>
            <div class="option">
                <input type="radio" id="dependents-yes" name="dependents" value="175"><label for="dependents-yes">Yes</label>
            </div>
            <div class="option">
                <input type="radio" id="dependents-no" name="dependents" value="0" checked><label for="dependents-no">No</label>
            </div>
        </div>
        <div class="button-container">
        <button type="button" class="prev-btn">Previous</button>
        <button type="button" class="next-btn">Next</button>
</div>
        </div>
        <!-- Step 3 -->
        <div class="form-step" id="step-3" style="display:none;">
        <div class="question-container">
            <div class="question"><span class="question-number">3</span>Please select all of your income sources:</div>
            <fieldset class="question-container question-3">
    <legend>Please select all of your income sources:</legend>
    <div class="options-container">
    
    <label><input type="checkbox" id="income-w2" name="income-sources[w2]" value="0"> Wages and Salaries reported on Forms W-2</label><br>
    
    <label><input type="checkbox" id="income-self" name="income-sources[self]" value="325-900"> Self-employment income</label><br>
    
    <label><input type="checkbox" id="income-rental-checkbox" name="income-sources[rental]" value="200"> Rental income</label>
    <div id="rental-properties-count" style="display:none;">
        <label for="income-rental">Number of properties:</label>
        <input type="number" id="income-rental" name="income-sources[rental-properties]" min="0" value="0">
    </div><br>
    
    <label><input type="checkbox" id="income-interest" name="income-sources[interest]" value="50-250"> Interest and Dividend income</label><br>
    
    <label><input type="checkbox" id="income-retirement" name="income-sources[retirement]" value="50-250"> Retirement income</label><br>
    
    <label><input type="checkbox" id="income-social" name="income-sources[social]" value="0"> Social Security income</label><br>
    
    <label><input type="checkbox" id="income-investment" name="income-sources[investment]" value="125-300"> Investment income</label><br>
    
    <label><input type="checkbox" id="income-foreign" name="income-sources[foreign]" value="375-2500"> Foreign Sourced income</label><br>
    
    <label><input type="checkbox" id="income-other" name="income-sources[other]" value="50-250"> Other (alimony, royalties, gambling winnings, etc.)</label><br>
</div>
</fieldset>

        </div>
        <div class="button-container">
        <button type="button" class="prev-btn">Previous</button>
        <button type="button" class="next-btn">Next</button>
</div>
        </div>

        <!-- Step 4 -->
        <div class="form-step" id="step-3" style="display:none;">

        <div class="question-container">
            <div class="question"><span class="question-number">4</span>Do you have any pass-through income?</div>
                <div class="option">
                    <input type="radio" id="passthrough-yes" name="passthrough-income" value="yes"><label for="passthrough-yes">Yes</label>
                </div>
                <div class="option">
                    <input type="radio" id="passthrough-no" name="passthrough-income" value="no" checked><label for="passthrough-no">No</label>
                </div>
                <div id="k1-counter" style="display:none;">
                    <label for="k1-count">How many K-1s?</label>
                    <input type="number" id="k1-count" name="k1-count" min="0" value="0">
                </div>
        </div>
        <div class="button-container">
        <button type="button" class="prev-btn">Previous</button>
        <button type="button" class="next-btn">Next</button>
</div>
        </div>

        <!-- Step 5 -->
    <div class="form-step" id="step-3" style="display:none;">
        <div class="question-container">
            <div class="question"><span class="question-number">5</span>Do you itemize your deductions?
                </div>
            <div class="option">
                <input type="radio" id="deductions-yes" name="deductions" value="200"><label for="deductions-yes">Yes</label>
            </div>
            <div class="option">
                <input type="radio" id="deductions-no" name="deductions" value="0" checked><label for="deductions-no">No</label>
            </div>
        </div>
        <div class="button-container">
            <button type="button" class="prev-btn">Previous</button>
            <button type="button" id="calculate-cost">Submit to Calculate Cost</button>
        </div>
    </div> 
    
        
    </form>
    <div id="progress-tracker">
        <p id="progress-text">Just 5 Questions</p>
        <progress id="progress-bar" value="0" max="5"></progress> <!-- Replace Y with the total number of questions -->
    </div>
    <div id="total-cost" style="display:none;">Your Price Estimate: $0</div>
</div>

    <?php
    return ob_get_clean();
}

add_shortcode('tax_calculator', 'tax_calculator_shortcode');
