document.addEventListener('DOMContentLoaded', function() {

    // Toggle the display of the rental properties input based on the checkbox
    document.getElementById('income-rental-checkbox').addEventListener('change', function() {
        var rentalPropertiesInput = document.getElementById('rental-properties-count');
        if (this.checked) {
            rentalPropertiesInput.style.display = 'block';
        } else {
            rentalPropertiesInput.style.display = 'none';
            // Optionally reset the number of properties to 0 when unchecked
            document.getElementById('income-rental').value = 0;
        }
    });

    // Show/hide the K-1 count input based on pass-through income selection
    document.querySelectorAll('input[name="passthrough-income"]').forEach(input => {
        input.addEventListener('change', function() {
            const k1CounterDisplay = document.getElementById('passthrough-yes').checked ? 'block' : 'none';
            document.getElementById('k1-counter').style.display = k1CounterDisplay;
        });
    });
    // Listen for the Calculate Cost button click event
    document.getElementById('calculate-cost').addEventListener('click', function() {
        var totalMin = 0;
        var totalMax = 0;

        // Filing Status - fixed value, same for min and max
        var filingStatus = parseInt(document.getElementById('filing-status').value);
        console.log(filingStatus);
        totalMin += filingStatus;
        totalMax += filingStatus;
        console.log(totalMin);
        console.log(totalMax);

        // Dependents - fixed value, same for min and max
        var dependents = document.querySelector('input[name="dependents"]:checked').value;
        totalMin += parseInt(dependents);
        totalMax += parseInt(dependents);

        // Income Sources - variable ranges
          // Self-employment income
    if (document.getElementById('income-self').checked) {
        var selfEmploymentRange = document.getElementById('income-self').value.split('-');
        totalMin += parseInt(selfEmploymentRange[0]);
        totalMax += parseInt(selfEmploymentRange[1]);
    }

    // Rental income
    if (document.getElementById('income-rental-checkbox').checked) {
        var rentalProperties = parseInt(document.getElementById('income-rental').value || 0);
        totalMin += rentalProperties * 200;
        totalMax += rentalProperties * 200;
    }

    // Interest and Dividend income
    if (document.getElementById('income-interest').checked) {
        var interestIncomeRange = document.getElementById('income-interest').value.split('-');
        totalMin += parseInt(interestIncomeRange[0]);
        totalMax += parseInt(interestIncomeRange[1]);
    }

    // Retirement income
    if (document.getElementById('income-retirement').checked) {
        var retirementIncomeRange = document.getElementById('income-retirement').value.split('-');
        totalMin += parseInt(retirementIncomeRange[0]);
        totalMax += parseInt(retirementIncomeRange[1]);
    }

    // Social Security income, which has a value of $0
    if (document.getElementById('income-social').checked) {
        // Since it's $0, it doesn't actually change the total, but this is how you'd add it.
    }

    // Investment income
    if (document.getElementById('income-investment').checked) {
        var investmentIncomeRange = document.getElementById('income-investment').value.split('-');
        totalMin += parseInt(investmentIncomeRange[0]);
        totalMax += parseInt(investmentIncomeRange[1]);
    }

    // Foreign Sourced income
    if (document.getElementById('income-foreign').checked) {
        var foreignIncomeRange = document.getElementById('income-foreign').value.split('-');
        totalMin += parseInt(foreignIncomeRange[0]);
        totalMax += parseInt(foreignIncomeRange[1]);
    }

    // Other income
    if (document.getElementById('income-other').checked) {
        var otherIncomeRange = document.getElementById('income-other').value.split('-');
        totalMin += parseInt(otherIncomeRange[0]);
        totalMax += parseInt(otherIncomeRange[1]);
    }

        // Pass-through income - based on additional K-1 forms
        var passThroughYes = document.getElementById('passthrough-yes').checked;
        console.log(passThroughYes);
        if (passThroughYes) {
            // Assuming $50 per additional K-1 as min and max beyond the first one (adjust logic as needed)
            var k1Count = parseInt(document.getElementById('k1-count').value || 0); // Or any logic to determine the number
            if (k1Count > 1) { // Check if there's more than one K-1 form
                totalMin += (k1Count - 1) * 50; // Subtract 1 to exclude the first K-1
                totalMax += (k1Count - 1) * 50;
            }
        }

        // Itemize Deductions - fixed value, same for min and max
        var itemizeDeductions = document.querySelector('input[name="deductions"]:checked').value;
        totalMin += parseInt(itemizeDeductions);
        totalMax += parseInt(itemizeDeductions);

        // Display the total cost range
        var totalCostDiv = document.getElementById('total-cost');
        totalCostDiv.textContent = 'Your Price Estimate: $' + (totalMin-100) + ' - $' + totalMax;
        totalCostDiv.style.display = 'block'; // Make the total cost div visible

        // Update the progress bar to indicate completion
        const progressBar = document.getElementById('progress-bar');
        if (progressBar) {
        progressBar.value = progressBar.max; // Set progress to full
    }
        // Update the progress text to indicate completion
        const progressText = document.getElementById('progress-text');
        if (progressText) {
            progressText.innerText = 'Estimate is Ready!'; // Adjust text as needed
        }
    });

        // Multi-step form navigation logic


    let currentStep = 1;
    const totalQuestions = 5; // Assuming 5 total questions, adjust as per your form
    const steps = document.querySelectorAll('.form-step');
    const nextBtns = document.querySelectorAll('.next-btn');
    const prevBtns = document.querySelectorAll('.prev-btn');
    // Initialize the progress bar on first load
    updateProgressBar(currentStep, totalQuestions);

    function showStep(step) {
        steps.forEach((div, index) => {
            if (index + 1 === step) {
                div.style.display = 'block';
                div.classList.add('active-step');
            } else {
                div.style.display = 'none';
                div.classList.remove('active-step');
            }
        });
        currentStep = step;
        //document.getElementById('tax-calculator').scrollIntoView({
          //  behavior: 'smooth'
        //});
        // Update the progress bar each time the step changes
        updateProgressBar(currentStep, totalQuestions);
    }

    nextBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (currentStep < steps.length) {
                showStep(currentStep + 1);
            }
        });
    });

    prevBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (currentStep > 1) {
                showStep(currentStep - 1);
            }
        });
    });

    // Show the first step on initial load
    showStep(1);
    // Function to update the progress bar and text
    function updateProgressBar(currentStep, totalQuestions) {
        // Assuming you have a <progress> element with id="progress-bar"
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('progress-text');
        if (progressBar && progressText) {
            progressBar.max = totalQuestions;
            progressBar.value = currentStep -1;
            // Update progress text
            const questionsLeft = totalQuestions - currentStep + 1; // Adjust based on whether the last step includes calculating cost
            progressText.innerText = `Just ${questionsLeft} Questions Left`;
        }
    }
});
